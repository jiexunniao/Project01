create view gc_schedule_scheduler_check_v as
  select `t3`.`name` AS `name`, `t3`.`pid` AS `pid`, `t3`.`day` AS `checkTime`, `t3`.`events` AS `checkStatus`
  from `demo`.`gc_schedule_scheduler` `t3`
  where (`t3`.`pid` in (select `gc_schedule_check_v`.`pid` from `demo`.`gc_schedule_check_v`) and
         (not(`t3`.`day` in (select `gc_schedule_check_v`.`checkTime` from `demo`.`gc_schedule_check_v`))))
  order by `t3`.`pid`;

