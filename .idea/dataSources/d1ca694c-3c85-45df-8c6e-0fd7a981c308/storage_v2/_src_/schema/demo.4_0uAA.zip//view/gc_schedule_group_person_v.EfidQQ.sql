create view gc_schedule_group_person_v as
  select `t1`.`pid` AS `pid`, `t1`.`name` AS `name`, `t2`.`groupName` AS `groupName`, `t2`.`gid` AS `gid`
  from (`demo`.`gc_schedule_person` `t1` left join `demo`.`gc_schedule_group` `t2` on ((`t2`.`groupItem` like
                                                                                        concat('%', `t1`.`name`,
                                                                                               '%'))));

