create view gc_schedule_check_v as
  select `t2`.`name`                               AS `name`,
         `t1`.`pid`                                AS `pid`,
         date_format(`t1`.`checkTime`, '%Y-%m-%d') AS `checkTime`,
         `t1`.`checkStatus`                        AS `checkStatus`
  from (`demo`.`gc_schedule_check` `t1` join `demo`.`gc_schedule_person` `t2` on ((`t1`.`pid` = `t2`.`pid`)))
  order by `t1`.`pid`;

