create view gc_schedule_check_statistics_v as select `gc_schedule_check_v`.`name`        AS `name`,
                                                     `gc_schedule_check_v`.`pid`         AS `pid`,
                                                     `gc_schedule_check_v`.`checkTime`   AS `checkTime`,
                                                     `gc_schedule_check_v`.`checkStatus` AS `checkStatus`
                                              from `demo`.`gc_schedule_check_v`
                                              union select `gc_schedule_scheduler_check_v`.`name`        AS `name`,
                                                           `gc_schedule_scheduler_check_v`.`pid`         AS `pid`,
                                                           `gc_schedule_scheduler_check_v`.`checkTime`   AS `checkTime`,
                                                           `gc_schedule_scheduler_check_v`.`checkStatus` AS `checkStatus`
                                                    from `demo`.`gc_schedule_scheduler_check_v`;

